package ar.edu.ort.tp1.pacial2.clases;

import ar.edu.ort.tp1.tdas.implementaciones.PilaNodos;
import ar.edu.ort.tp1.tdas.interfaces.Pila;

public class Estante implements Depositante<Producto, Integer> {

	//TODO Completar
	private Pila<Producto> ubicaciones;
	private int cantidadAlojados;
	private int profundidadEstanteria;

	public Estante(int profundidadEstanteria) {
		this.profundidadEstanteria = profundidadEstanteria;
		this.ubicaciones = new PilaNodos<>();
	}

	/**
	 * Agrega un elemento al estante siempre y cuando haya lugar, sino, deber� emitir la excepci�n que corresponda..
	 */
	@Override
	public void depositar(Producto p) throws RuntimeException {

		if (profundidadEstanteria == cantidadAlojados) {
			throw new RuntimeException("No se pueden agregar mas productos a este estante.");
		}
		ubicaciones.push(p);
		cantidadAlojados++;
	}

	/**
	 * Retira el producto de la estanter�a por su id
	 */
	@Override
	public Producto retirarPorId(Integer id) {
		Producto retorno = null;
		Pila<Producto> aux = new PilaNodos<>();
		while (retorno == null && !this.ubicaciones.isEmpty()) {
			Producto productoAuxiliar = ubicaciones.pop();
			if (productoAuxiliar.coincideId(id)) {
				retorno = productoAuxiliar;
			} else {
				aux.push(productoAuxiliar);
			}
		}

		while (!aux.isEmpty()) {
			ubicaciones.push(aux.pop());
		}

		return retorno;
	}

}
