package ar.edu.ort.tp1.parcial1.clases;

public class Doctor {
	private String nombre;

	public Doctor(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}
}
