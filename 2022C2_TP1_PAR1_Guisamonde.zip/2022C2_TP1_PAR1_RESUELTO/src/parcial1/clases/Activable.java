package parcial1.clases;

public interface Activable {
	void activar();
	void desactivar();
	boolean estaActivada();
}
