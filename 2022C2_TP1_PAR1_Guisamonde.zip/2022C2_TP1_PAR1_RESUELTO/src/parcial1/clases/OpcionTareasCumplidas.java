package parcial1.clases;

import parcial1.clases.protegidas.OpcionAccesoAMenu;

public class OpcionTareasCumplidas extends OpcionAccesoAMenu {

	public OpcionTareasCumplidas(String descripcion, char charSelector, MenuDeTareas menuSecundario) {
		super(descripcion, charSelector, menuSecundario);
	}

	@Override
	public void ejecutar() {
		System.out.println("Cantidad de tareas cumplidas: " + ((MenuDeTareas) getMenu()).getTotalTareasCumplidas());
	}

}
