package parcial1.clases;

public interface Ejecutable {
	void ejecutar();
}
