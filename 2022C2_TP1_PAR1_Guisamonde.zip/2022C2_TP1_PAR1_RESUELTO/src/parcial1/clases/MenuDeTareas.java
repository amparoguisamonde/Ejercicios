package parcial1.clases;

import java.util.Scanner;

import parcial1.clases.protegidas.Menu;

public class MenuDeTareas extends Menu {

	public MenuDeTareas(String titulo, Scanner input) {
		super(titulo, input);
	}

	public void registrar(OpcionDeMenu opcion) {
		if (opcion instanceof OpcionOnOff)
			super.registrar(opcion);
	}

	public int getTotalTareasCumplidas() {
		int cant = 0;
		for (OpcionDeMenu opcion : getReadOnlyItems()) {
			if (opcion instanceof Activable && ((Activable) opcion).estaActivada())
				cant++;
		}
		return cant;
	}

}