package examen.clases;

public enum Calidad {
	DESEADA, ACEPTABLE, DESCARTE
}