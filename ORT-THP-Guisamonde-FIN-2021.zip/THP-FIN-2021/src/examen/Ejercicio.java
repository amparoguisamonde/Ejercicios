package examen;

import examen.clases.FabricaDeGalletitas;

public class Ejercicio {
	public static void main(String[] args) {
		FabricaDeGalletitas fabrica = new FabricaDeGalletitas();
		fabrica.envasar();
	}
}
